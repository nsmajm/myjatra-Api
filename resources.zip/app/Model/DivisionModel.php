<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class DivisionModel extends Model
{
    protected $table="division";
    protected $primaryKey="division_id";
    public $timestamps=false;
}
