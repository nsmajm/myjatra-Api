<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class SubDistrictModel extends Model
{
    protected $table="sub_district";
    protected $primaryKey="sub_district_id";
    public $timestamps=false;
}
