<?php

namespace App\Http\Controllers;

use App\Model\HotelImageModel;
use App\Model\HotelInfoModel;
use App\Model\RoomPriceModel;
use Illuminate\Http\Request;

class HotelController extends Controller
{
    public function hotelDetails(Request $request){
        $hotelInfo = HotelInfoModel::findOrFail($request->id);
        $roomPrice = RoomPriceModel::select('roomName','roomPrice')->where('hotel_id',$request->id)->get();
        $hotelImage = HotelImageModel::select('image_path')->where('hotel_id',$request->id)->get();
        return response()->json(array('hotelInfo'=>$hotelInfo,'roomPrice'=>$roomPrice,'hotelImage'=>$hotelImage));
    }
    public function getAllHotel(){
        $hotelInfo = HotelInfoModel::paginate(10);
        return response()->json($hotelInfo);
    }
}
